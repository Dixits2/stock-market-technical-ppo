import gym
import json
import datetime as dt
from stable_baselines.common.policies import MlpPolicy
from stable_baselines.common import make_vec_env
from stable_baselines.common.vec_env.base_vec_env import VecEnvWrapper
from stable_baselines import PPO2
import gym_stocks
import pandas as pd
import numpy as np
import os


# The algorithms require a vectorized environment to run
p_sum = 0
model_timesteps = 14000000
iterations = 1
high = 0
low = 0
test_days = 1000
for j in range(iterations):
	env = make_vec_env('Stocks-v0', n_envs=16)
	model = PPO2(MlpPolicy, env, verbose=1, tensorboard_log="./ppo2_stocks/")
	model.learn(total_timesteps=model_timesteps)

	env = gym.make('Stocks-v0')
	obs = env.reset()
	# cum_reward = 0
	cum_profit = 0
	for i in range(test_days):
	  # inp = input("Enter an action: ")
	  action, _states = model.predict(obs)
	  obs, rewards, done, info = env.step(action)
	  # print(env.action_space.low)
	  # print(env.action_space.high)
	  # print(env.action_space.sample())
	  # print(rewards)

	  # env.render()
	  # print("Reward: %g" % rewards)
	  # print("----------")

	  if i == test_days - 1:
	  	cum_profit += env.get_profit()
	  else:
	    if done:
	  	  cum_profit += env.get_profit()
	  	  obs = env.reset()
	  	  # print("--------------Env Reset------------")
	p_sum += cum_profit/test_days
print(p_sum/iterations)
	








# import os
# import pandas as pd
# import numpy as np
# import requests
# from io import StringIO
# import time
# import gym_stocks

# call sequence:
# step


# import gym
# env = gym.make('Stocks-v0')
# print(env.reset())
# print(len(env.all_data))
# # print(np.finfo(np.float32).max)
# # print(env.all_data[(env.current_pos - env.VISIBLE_PAST_DAYS):env.current_pos])
# # print(env.current_pos)
# # a = time.time()
# # b = env.get_high()
# # c = time.time()
# # d = env.action_space.high
# # e = time.time()
# # f = env.action_space.sample()
# # g = time.time()
# # print(str(b) + " " + str(c - a))
# # print(str(d) + " " + str(e - c))
# # print(str(f) + " " + str(g - e))
# env.close()


# # start = time.time()
# # df = pd.read_csv(StringIO(requests.get('http://127.0.0.1:5000/').json()), sep=",").drop(["OpenInt"], axis=1)
# # end = time.time()

# # print(df)
# # # print(end-start)
# # # print(df.at[0, 'Close'])
# # print(df[0:30].to_numpy())

# # x = 0


# files = [i for i in os.listdir("Stocks") if i.endswith("txt")]

# P_CNT = 7

# total_lines = 0

# for file in files:
# 	content = open('Stocks/' + file)
# 	num_lines = sum(1 for line in content)
# 	total_lines += num_lines - P_CNT

# print(total_lines)
# print(len(files))
# print(total_lines/len(files))



