import requests

for i in range(10000):
	print(i)
	requests.get(url="http://127.0.0.1:5000/")