from flask import Flask, request
from flask_restful import Resource, Api
import os

files = [i for i in os.listdir("Stocks") if i.endswith("txt")]

current_file = 0

app = Flask(__name__)
api = Api(app)


class Basic(Resource):
	def get(self):
		global files
		global current_file
		with app.open_resource('Stocks/' + files[current_file]) as f:
			contents = f.read()
			if current_file == 6813:
				current_file = 0
			else:
				current_file += 1
			return contents.decode('utf-8')
		
api.add_resource(Basic, '/')

if __name__ == '__main__':
	 app.run(port='5000')