import os
os.system(
    "tensorboard --logdir ./ppo2_stocks/"
) 